function check() {
    var a = document.getElementById("input").value;
    var b=  Math.floor(Math.random() * 11);
    if (a==b){
        document.write("congartulations!! " + a + " is  the correct number");

    } else{
        document.write( `${a} is not the correct number`)
    }
    
    
}
